<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $conn->prepare('SELECT id, username, email, role_id FROM users WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$target = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$target) {
    flash('error', 'User not found.');
    header('Location: users_list.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email       = trim($_POST['email'] ?? '');
    $roleId      = (int)($_POST['role_id'] ?? 2);
    $newPassword = $_POST['new_password'] ?? '';

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (!in_array($roleId, [1, 2], true)) $errors[] = 'Invalid role selected.';
    if ($newPassword !== '' && strlen($newPassword) < 8) $errors[] = 'New password must be at least 8 characters.';

    if (!$errors) {
        $stmt = $conn->prepare('SELECT id FROM users WHERE email = ? AND id != ?');
        $stmt->bind_param('si', $email, $id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) $errors[] = 'That email is already in use by another account.';
        $stmt->close();
    }

    if (!$errors) {
        if ($newPassword !== '') {
            $hash = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $conn->prepare('UPDATE users SET email = ?, role_id = ?, password_hash = ? WHERE id = ?');
            $stmt->bind_param('sisi', $email, $roleId, $hash, $id);
        } else {
            $stmt = $conn->prepare('UPDATE users SET email = ?, role_id = ? WHERE id = ?');
            $stmt->bind_param('sii', $email, $roleId, $id);
        }
        $stmt->execute();
        $stmt->close();

        flash('success', 'User updated.');
        header('Location: users_list.php');
        exit;
    }

    $target['email'] = $email;
    $target['role_id'] = $roleId;
}

$pageTitle = 'users_edit.php — Task 3';
$activeTab = 'users';
include __DIR__ . '/includes/header.php';
?>
<p class="editor-heading"><span class="kw">function</span> <span class="fn">editUser</span>(<?= (int)$target['id'] ?>) {</p>
<p class="editor-subtitle">Editing <strong><?= htmlspecialchars($target['username']) ?></strong>.</p>

<?php if ($errors): ?>
  <div class="alert-box">
    <?php foreach ($errors as $e): ?><p><?= htmlspecialchars($e) ?></p><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)$target['id'] ?>">
  <div class="field">
    <label class="field-label">username</label>
    <input type="text" class="form-control" value="<?= htmlspecialchars($target['username']) ?>" disabled>
  </div>
  <div class="field">
    <label class="field-label" for="email">email</label>
    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($target['email']) ?>" required>
  </div>
  <div class="field">
    <label class="field-label" for="role_id">role</label>
    <select class="form-control" id="role_id" name="role_id">
      <option value="2" <?= $target['role_id'] == 2 ? 'selected' : '' ?>>user</option>
      <option value="1" <?= $target['role_id'] == 1 ? 'selected' : '' ?>>admin</option>
    </select>
  </div>
  <div class="field">
    <label class="field-label" for="new_password">new password</label>
    <div class="input-wrap">
      <input type="password" class="form-control" id="new_password" name="new_password" minlength="8">
      <button type="button" class="toggle-visibility" data-target="new_password" aria-label="Show password"><i class="bi bi-eye"></i></button>
    </div>
    <div class="field-hint">leave blank to keep the current password</div>
  </div>
  <button type="submit" class="run-btn"><i class="bi bi-play-fill"></i> save changes</button>
</form>
<p class="switch-line"><a href="users_list.php">← back to users.php</a></p>
<?php include __DIR__ . '/includes/footer.php'; ?>
