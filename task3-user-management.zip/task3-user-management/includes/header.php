<?php
$navUser = function_exists('current_user') ? current_user() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? 'ApexPlanet — Task 3') ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="editor-window<?= !empty($wide) ? ' editor-window-wide' : '' ?>">
  <div class="title-bar">
    <span class="dot red"></span>
    <span class="dot amber"></span>
    <span class="dot green"></span>
    <span class="title-bar-label">apexplanet-internship — task-3 backend</span>
  </div>

  <nav class="tab-bar">
    <?php if ($navUser): ?>
      <a href="dashboard.php" class="tab<?= ($activeTab ?? '') === 'dashboard' ? ' active' : '' ?>">dashboard.php</a>
      <a href="profile.php" class="tab<?= ($activeTab ?? '') === 'profile' ? ' active' : '' ?>">profile.php</a>
      <?php if ($navUser['role'] === 'admin'): ?>
        <a href="users_list.php" class="tab<?= ($activeTab ?? '') === 'users' ? ' active' : '' ?>">users.php</a>
      <?php endif; ?>
      <a href="logout.php" class="tab">logout.php</a>
    <?php else: ?>
      <a href="login.php" class="tab<?= ($activeTab ?? '') === 'login' ? ' active' : '' ?>">login.php</a>
      <a href="register.php" class="tab<?= ($activeTab ?? '') === 'register' ? ' active' : '' ?>">register.php</a>
    <?php endif; ?>
  </nav>

  <div class="editor-body">
    <?php foreach (get_flashes() as $f): ?>
      <div class="flash flash-<?= htmlspecialchars($f['type']) ?>"><?= htmlspecialchars($f['message']) ?></div>
    <?php endforeach; ?>
