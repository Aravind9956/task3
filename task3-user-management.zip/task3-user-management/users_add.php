<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

$errors = [];
$old = ['username' => '', 'email' => '', 'role_id' => 2];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $roleId   = (int)($_POST['role_id'] ?? 2);
    $old = ['username' => $username, 'email' => $email, 'role_id' => $roleId];

    if (strlen($username) < 3) $errors[] = 'Username must be at least 3 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if (!in_array($roleId, [1, 2], true)) $errors[] = 'Invalid role selected.';

    if (!$errors) {
        $stmt = $conn->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) $errors[] = 'Username or email already exists.';
        $stmt->close();
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('INSERT INTO users (username, email, password_hash, role_id) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('sssi', $username, $email, $hash, $roleId);
        $stmt->execute();
        $stmt->close();

        flash('success', 'User created.');
        header('Location: users_list.php');
        exit;
    }
}

$pageTitle = 'users_add.php — Task 3';
$activeTab = 'users';
include __DIR__ . '/includes/header.php';
?>
<p class="editor-heading"><span class="kw">function</span> <span class="fn">addUser</span>() {</p>
<p class="editor-subtitle">Create a new user record directly from the admin panel.</p>

<?php if ($errors): ?>
  <div class="alert-box">
    <?php foreach ($errors as $e): ?><p><?= htmlspecialchars($e) ?></p><?php endforeach; ?>
  </div>
<?php endif; ?>

<form method="post" novalidate>
  <?= csrf_field() ?>
  <div class="field">
    <label class="field-label" for="username">username</label>
    <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($old['username']) ?>" required minlength="3">
  </div>
  <div class="field">
    <label class="field-label" for="email">email</label>
    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($old['email']) ?>" required>
  </div>
  <div class="field">
    <label class="field-label" for="password">password</label>
    <div class="input-wrap">
      <input type="password" class="form-control" id="password" name="password" required minlength="8">
      <button type="button" class="toggle-visibility" data-target="password" aria-label="Show password"><i class="bi bi-eye"></i></button>
    </div>
  </div>
  <div class="field">
    <label class="field-label" for="role_id">role</label>
    <select class="form-control" id="role_id" name="role_id">
      <option value="2" <?= $old['role_id'] == 2 ? 'selected' : '' ?>>user</option>
      <option value="1" <?= $old['role_id'] == 1 ? 'selected' : '' ?>>admin</option>
    </select>
  </div>
  <button type="submit" class="run-btn"><i class="bi bi-play-fill"></i> create user</button>
</form>
<p class="switch-line"><a href="users_list.php">← back to users.php</a></p>
<?php include __DIR__ . '/includes/footer.php'; ?>
