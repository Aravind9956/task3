/* Password show/hide toggle, reused on every password field across
   register.php, login.php, users_add.php, users_edit.php, and
   profile.php. Delete confirmation for users_list.php is handled
   inline via onsubmit="return confirm(...)" on the delete form. */

document.querySelectorAll('.toggle-visibility').forEach((btn) => {
  btn.addEventListener('click', () => {
    const input = document.getElementById(btn.dataset.target);
    const icon = btn.querySelector('i');
    const showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    icon.className = showing ? 'bi bi-eye' : 'bi bi-eye-slash';
    btn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
  });
});
