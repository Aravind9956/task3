<?php
require_once __DIR__ . '/includes/auth.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $id = (int)($_POST['id'] ?? 0);
    $me = current_user();

    if ($id === (int)$me['id']) {
        flash('error', 'You cannot delete your own account while signed in as it.');
    } else {
        $stmt = $conn->prepare('DELETE FROM users WHERE id = ?');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $affected = $stmt->affected_rows;
        $stmt->close();

        flash($affected ? 'success' : 'error', $affected ? 'User deleted.' : 'User not found.');
    }
}

header('Location: users_list.php');
exit;
