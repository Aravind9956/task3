<?php
require_once __DIR__ . '/includes/auth.php';
require_login();
$user = current_user();

$pageTitle = 'dashboard.php — Task 3';
$activeTab = 'dashboard';
include __DIR__ . '/includes/header.php';
?>
<p class="editor-heading"><span class="kw">function</span> <span class="fn">dashboard</span>() {</p>
<p class="editor-subtitle">
  Signed in as <strong><?= htmlspecialchars($user['username']) ?></strong>
  · role: <span class="role-badge role-<?= htmlspecialchars($user['role']) ?>"><?= htmlspecialchars($user['role']) ?></span>
</p>

<div class="dashboard-grid">
  <a class="dash-card" href="profile.php">
    <i class="bi bi-person-circle"></i>
    <span>Edit profile</span>
  </a>
  <?php if ($user['role'] === 'admin'): ?>
  <a class="dash-card" href="users_list.php">
    <i class="bi bi-people"></i>
    <span>Manage users</span>
  </a>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
